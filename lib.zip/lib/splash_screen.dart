import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'PermissionService.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  bool _isConnected = true;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    // Set up animation
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 400000),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_animationController);
    _animationController.forward();

    // Initialize the app
    _initializeApp();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _initializeApp() async {
    // Give the splash screen some time to display
    await Future.delayed(const Duration(seconds: 2));

    // Check internet connectivity
    await _checkConnectivity();

    if (!_isConnected) {
      _showNoInternetDialog();
      return;
    }

    // Request permissions
    await _requestPermissions();

    // Check if user is logged in
    await _checkAuthentication();
  }

  Future<void> _checkConnectivity() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    setState(() {
      _isConnected = connectivityResult != ConnectivityResult.none;
    });
  }

  Future<void> _requestPermissions() async {
    await PermissionService().requestPermissions();
  }

  Future<void> _checkAuthentication() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String? token = prefs.getString('auth_token');

      if (token != null && token.isNotEmpty) {
        _navigateToDashboard();
      } else {
        _navigateToLogin();
      }
    } catch (e) {
      print('Error checking authentication: $e');
      _navigateToLogin();
    }
  }

  void _navigateToLogin() {
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  void _navigateToDashboard() {
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    }
  }

  void _showNoInternetDialog() {
    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('No Internet Connection'),
            content: const Text(
              'Please check your internet connection and try again.',
            ),
            actions: <Widget>[
              TextButton(
                child: const Text('Retry'),
                onPressed: () {
                  Navigator.of(context).pop();
                  _initializeApp();
                },
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image
          Image.asset(
            'assets/images/cropnet_bg.png',
            fit: BoxFit.cover,
          ),
          // Content with fade animation
          FadeTransition(
            opacity: _fadeAnimation,
            child: Column(
              children: [
                // Logo positioned 50dp from top
                SizedBox(height: 50),
                Image.asset(
                  'assets/images/logo.png',
                  height: 100,
                ),
                const SizedBox(height: 30),
                const Text(
                  'THE NEW ERA OF',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.brown),
                ),
                const Text(
                  '🌾 AGRICULTURE',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green),
                ),
                const SizedBox(height: 30),
                const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                ),
              ],
            ),
          ),
          // Bottom button
       /*   Positioned(
            left: 0,
            right: 0,
            bottom: 20,
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Center(
                child: OutlinedButton(
                  onPressed: _isConnected ? () => _initializeApp() : null,
                  style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    side: const BorderSide(color: Colors.white, width: 2),
                    minimumSize: const Size(200, 45),
                  ),
                  child: const Text('Get Started', style: TextStyle(color: Colors.white, fontSize: 18)),
                ),
              ),
            ),
          ),*/
          Positioned(
            left: 0,
            right: 0,
            bottom: 20,
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Center(
                child: OutlinedButton(
                  onPressed: _isConnected ? () {
                    _initializeApp();
                    // Navigate to dashboard
                    Navigator.pushReplacementNamed(context, '/dashboard');
                  } : null,
                  style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    side: const BorderSide(color: Colors.white, width: 2),
                    minimumSize: const Size(200, 45),
                  ),
                  child: const Text('Get Started', style: TextStyle(color: Colors.white, fontSize: 18)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}