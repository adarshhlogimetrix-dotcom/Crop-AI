

class Constanst {


  String base_url = 'https://ccbfsolution.pmmsapp.com/api/';



}

/*
String image_url ='http://abyantaramo.idfcfirstbankshwetdhara.org/form_image/';*/
